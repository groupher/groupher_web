export type TView = 'list' | 'search'
export type TLayout = 'edit-works' | 'works' | 'guide-contribute'
