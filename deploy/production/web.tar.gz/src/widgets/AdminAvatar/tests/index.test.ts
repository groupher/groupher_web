// import React from 'react'
// import { shallow } from 'enzyme'

// import AdminAvatar from '../index'

describe('TODO <AdminAvatar />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
