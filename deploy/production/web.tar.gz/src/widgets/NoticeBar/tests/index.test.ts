// import React from 'react'
// import { shallow } from 'enzyme'

// import NoticeBar from '../index'

describe('TODO <NoticeBar />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
