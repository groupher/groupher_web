// import React from 'react'
// import { shallow } from 'enzyme'

// import CommunityList from '../index'

describe('TODO <CommunityList />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
