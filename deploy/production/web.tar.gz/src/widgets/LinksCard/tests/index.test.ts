// import React from 'react'
// import { shallow } from 'enzyme'

// import LinksCard from '../index'

describe('TODO <LinksCard />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
