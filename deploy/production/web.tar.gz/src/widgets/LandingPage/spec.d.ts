export type TFeatType = 'CHANGELOG' | 'HELP' | 'KANBAN' | 'DISCUSS'
