// import React from 'react'
// import { shallow } from 'enzyme'

// import CommunityStatesPad from '../index'

describe('TODO <CommunityStatesPad />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
