// import React from 'react'
// import { shallow } from 'enzyme'

// import ArticleBlongCommunity from '../index'

describe('TODO <ArticleBlongCommunity />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
