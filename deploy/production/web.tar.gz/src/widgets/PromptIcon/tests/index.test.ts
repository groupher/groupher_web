// import React from 'react'
// import { shallow } from 'enzyme'

// import PromptIcon from '../index'

describe('TODO <PromptIcon />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
