// import React from 'react'
// import { shallow } from 'enzyme'

// import FocusLine from '../index'

describe('TODO <FocusLine />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
