// import React from 'react'
// import { shallow } from 'enzyme'

// import Select from '../index'

describe('TODO <Select />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
