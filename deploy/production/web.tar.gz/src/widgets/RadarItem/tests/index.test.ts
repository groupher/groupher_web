// import React from 'react'
// import { shallow } from 'enzyme'

// import RadarItem from '../index'

describe('TODO <RadarItem />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
