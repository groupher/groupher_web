// import React from 'react'
// import { shallow } from 'enzyme'

// import UserCell from '../index'

describe('TODO <UserCell />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
