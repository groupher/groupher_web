// import React from 'react'
// import { shallow } from 'enzyme'

// import SupportUs from '../index'

describe('TODO <SupportUs />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
