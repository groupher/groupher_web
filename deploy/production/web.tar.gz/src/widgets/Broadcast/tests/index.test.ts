// import React from 'react'
// import { shallow } from 'enzyme'

// import Broadcast from '../index'

describe('TODO <Broadcast />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
