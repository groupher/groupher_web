// import React from 'react'
// import { shallow } from 'enzyme'

// import ColorSelector from '../index'

describe('TODO <ColorSelector />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
