// import React from 'react'
// import { shallow } from 'enzyme'

// import KanbanItem from '../index'

describe('TODO <KanbanItem />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
