// import React from 'react'
// import { shallow } from 'enzyme'

// import ArticleBaseStats from '../index'

describe('TODO <ArticleBaseStats />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
