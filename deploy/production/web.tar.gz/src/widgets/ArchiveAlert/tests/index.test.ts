// import React from 'react'
// import { shallow } from 'enzyme'

// import ArchiveAlert from '../index'

describe('TODO <ArchiveAlert />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
