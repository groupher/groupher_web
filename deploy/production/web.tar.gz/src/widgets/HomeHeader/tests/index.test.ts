// import React from 'react'
// import { shallow } from 'enzyme'

// import HomeHeader from '../index'

describe('TODO <HomeHeader />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
