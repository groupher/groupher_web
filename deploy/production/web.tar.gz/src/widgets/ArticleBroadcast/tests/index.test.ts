// import React from 'react'
// import { shallow } from 'enzyme'

// import ArticleBroadcast from '../index'

describe('TODO <ArticleBroadcast />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
