import { ICON_CMD } from '@/config'

const items = [
  {
    id: '1',
    title: 'Makers',
    link: 'https://xxxx',
    desc: '独立开发者，作品创作团队',
    cover: `${ICON_CMD}/test_ad.jpg`,
  },
  {
    id: '2',
    title: 'Web 大前端',
    link: 'https://xxxx',
    desc: '讨论 web 相关的各种话题',
    cover: `${ICON_CMD}/test_ad.jpg`,
  },
  {
    id: '3',
    title: 'xxoo',
    link: 'https://xxxx',
    desc: 'xxx 就不用多介绍了吧',
    cover: `${ICON_CMD}/test_ad.jpg`,
  },
  {
    id: '4',
    title: 'xxoo2',
    link: 'https://xxxx',
    desc: 'xxx2 就不用多介绍了吧',
    cover: `${ICON_CMD}/test_ad.jpg`,
  },
]

export default items
