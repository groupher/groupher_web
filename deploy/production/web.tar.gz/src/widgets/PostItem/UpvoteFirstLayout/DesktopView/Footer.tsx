import { memo, FC, Fragment } from 'react'
import { includes } from 'ramda'

import type { TPost } from '@/spec'
import { UPVOTE_LAYOUT, ARTICLE_CAT, ARTICLE_STATE } from '@/constant'

import Upvote from '@/widgets/Upvote'
import { Space } from '@/widgets/Common'
import ViewsCount from '@/widgets/ViewsCount'
import ArticleCatState from '@/widgets/ArticleCatState'

import { Wrapper } from '../../styles/upvote_fist_layout/desktop_view/footer'

type TProps = {
  article: TPost
}

const Footer: FC<TProps> = ({ article }) => {
  const { upvotesCount, meta, viewerHasUpvoted } = article

  const demoList = ['239', '231', '227', '228', '226', '225']

  return (
    <Wrapper>
      <Upvote
        count={upvotesCount}
        avatarList={meta.latestUpvotedUsers}
        viewerHasUpvoted={viewerHasUpvoted}
        type={UPVOTE_LAYOUT.GENERAL}
        left={-2}
        top={-1}
      />

      {!includes(article.id, demoList) ? (
        <ArticleCatState left={18} cat={article.category} state={article.state} top={1} />
      ) : (
        <Fragment>
          {article.id === '239' && <ArticleCatState cat={ARTICLE_CAT.FEATURE} left={18} top={1} />}
          {article.id === '231' && <ArticleCatState cat={ARTICLE_CAT.BUG} left={18} top={1} />}
          {article.id === '227' && (
            <ArticleCatState cat={ARTICLE_CAT.BUG} state="TODO" left={18} top={1} />
          )}
          {article.id === '228' && (
            <ArticleCatState cat={ARTICLE_CAT.FEATURE} state="WIP" left={18} top={1} />
          )}
          {article.id === '226' && (
            <ArticleCatState cat={ARTICLE_CAT.QUESTION} state="RESOLVE" left={18} top={1} />
          )}
          {article.id === '225' && (
            <ArticleCatState
              cat={ARTICLE_CAT.FEATURE}
              state={ARTICLE_STATE.REJECT_DUP}
              left={18}
              top={1}
            />
          )}
        </Fragment>
      )}

      <Space right={18} />
      <ViewsCount count={article.views} />
    </Wrapper>
  )
}

export default memo(Footer)
