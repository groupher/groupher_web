import styled from 'styled-components'

import css, { theme } from '@/utils/css'

export const Wrapper = styled.div`
  ${css.flex('align-center')};
  color: ${theme('article.info')};
  font-size: 11px;
  margin-bottom: 4px;
`
export const holder = 1
