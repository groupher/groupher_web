import styled from 'styled-components'

export const Wrapper = styled.article`
  width: 100%;
`
export const holder = 1
