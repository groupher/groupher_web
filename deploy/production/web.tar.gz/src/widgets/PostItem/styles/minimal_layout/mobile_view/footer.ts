import styled from 'styled-components'

import { Wrapper as WrapperDesktop } from '../desktop_view/footer'

export const Wrapper = styled(WrapperDesktop)``

export const holder = 1
