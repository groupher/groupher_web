// import React from 'react'
// import { shallow } from 'enzyme'

// import EmptyThread from '../index'

describe('TODO <EmptyThread />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
