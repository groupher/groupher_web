export type TMetric = 'post-item' | 'article-author'
export const holder = 1
