// import React from 'react'
// import { shallow } from 'enzyme'

// import TheAvatar from '../index'

describe('TODO <TheAvatar />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
