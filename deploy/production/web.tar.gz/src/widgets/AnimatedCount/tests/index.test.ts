// import React from 'react'
// import { shallow } from 'enzyme'

// import AnimatedCount from '../index'

describe('TODO <AnimatedCount />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
