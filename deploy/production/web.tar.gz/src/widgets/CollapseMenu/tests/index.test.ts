// import React from 'react'
// import { shallow } from 'enzyme'

// import CollapseMenu from '../index'

describe('TODO <CollapseMenu />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
