// import React from 'react'
// import { shallow } from 'enzyme'

// import WordsCounter from '../index'

describe('TODO <WordsCounter />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
