// import React from 'react'
// import { shallow } from 'enzyme'

// import BrandTitle from '../index'

describe('TODO <BrandTitle />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
