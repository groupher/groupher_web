// import React from 'react'
// import { shallow } from 'enzyme'

// import DivideText from '../index'

describe('TODO <DivideText />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
