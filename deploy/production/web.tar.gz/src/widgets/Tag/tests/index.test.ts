// import React from 'react'
// import { shallow } from 'enzyme'

// import Tag from '../index'

describe('TODO <Tag />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
