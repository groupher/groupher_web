// import React from 'react'
// import { shallow } from 'enzyme'

// import VerifiedSign from '../index'

describe('TODO <VerifiedSign />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
