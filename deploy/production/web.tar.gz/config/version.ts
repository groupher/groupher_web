export const APP_VERSION = "1.1.54"
