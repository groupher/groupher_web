export const APP_VERSION = "1.2.39"
