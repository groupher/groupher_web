export default {
  title: 'groupher',
  description: '来为你心爱的产品建立一个反馈社区吧。',
  cannotical: 'https://groupher.com',
  openGraph: {
    type: 'website',
    locale: 'zh_cn',
    url: 'https://groupher.com',
    site_name: 'groupher',
    description: '来为你心爱的产品建立一个反馈社区吧。',
  },
  /*
     twitter: {
     handle: '@handle',
     site: '@site',
     cardType: 'summary_large_image',
     },
   */
}
