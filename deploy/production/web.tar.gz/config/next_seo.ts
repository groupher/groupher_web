export default {
  title: 'groupher',
  description:
    '最性感的开发者社区 | the sexiest community for developers, ever.',
  cannotical: 'https://groupher.com',
  openGraph: {
    type: 'website',
    locale: 'zh_cn',
    url: 'https://groupher.com',
    site_name: 'groupher',
    description: '最性感的开发者社区',
  },
  /*
     twitter: {
     handle: '@handle',
     site: '@site',
     cardType: 'summary_large_image',
     },
   */
}
