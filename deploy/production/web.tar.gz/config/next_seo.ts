export default {
  title: 'coderplanets',
  description:
    '最性感的开发者社区 | the sexiest community for developers, ever.',
  cannotical: 'https://coderplanets.com',
  openGraph: {
    type: 'website',
    locale: 'zh_cn',
    url: 'https://coderplanets.com',
    site_name: 'coderplanets',
    description: '最性感的开发者社区',
  },
  /*
     twitter: {
     handle: '@handle',
     site: '@site',
     cardType: 'summary_large_image',
     },
   */
}
